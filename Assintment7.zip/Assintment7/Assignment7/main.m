//
//  main.m
//  Assignment7
//
//  Created by student on 4/8/13.
//  Copyright (c) 2013 Cody Berndt. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "assignAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([assignAppDelegate class]));
    }
}
