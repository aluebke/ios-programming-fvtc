//
//  assignViewController.m
//  Assignment7
//
//  Created by student on 4/8/13.
//  Copyright (c) 2013 Cody Berndt. All rights reserved.
//

#import "gamesViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface gamesViewController ()

@end

@implementation gamesViewController


- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    CGPoint p = [[touches anyObject] locationInView:[self view]];
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    NSString *board = @"12,1,15,2,9,24,30,22,18,21,34,43,45,31,42,54,30,58,56,55,68,63,70,72,62";
    //split the contents of the string into an array (separated by a ',')
    NSArray* boardNumbers = [board componentsSeparatedByString:@","];
    //loop through array to display, see if it worked
    for (NSString *n in boardNumbers)
    {
        NSLog(@"%@", n);
    }
    
    
    //display numbers into the grid.
    int counter = 0;
    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
        CATextLayer *labelLayer = [[CATextLayer alloc] init];
        [labelLayer setFont:@"Helvetica-Bold"];
        [labelLayer setFontSize:20];
        [labelLayer setString:[NSString stringWithFormat:@"%@", boardNumbers[counter]]];
        [labelLayer setForegroundColor:[UIColor blackColor].CGColor];
        [labelLayer setBorderColor:[UIColor redColor].CGColor];
        [labelLayer setBorderWidth:-1];
        
        
        [labelLayer setFrame:CGRectMake(0, 0, 54, 60)];
        labelLayer.position = CGPointMake(55 + (55 * i), 130 + (j * 60));
            
            [[[self view] layer] addSublayer:labelLayer];
            counter = counter +1;

        }
    }
            
    
    /*
    //***********Number Label1 ***************
    for (int i = 0; i < 3; i++)
    {
    CATextLayer *labelLayer = [[CATextLayer alloc] init];
    [labelLayer setFont:@"Helvetica-Bold"];
    [labelLayer setFontSize:20];
    [labelLayer setString:[NSString stringWithFormat:@"%i", i]];
    [labelLayer setForegroundColor:[UIColor blackColor].CGColor];
    [labelLayer setBorderColor:[UIColor redColor].CGColor];
    [labelLayer setBorderWidth:3];
    
    [labelLayer setFrame:CGRectMake(0,0,120, 30)];
    labelLayer.position = CGPointMake(80, 50 + (i * 100));
    
    [[[self view] layer] addSublayer:labelLayer];
    }*/
    
    
    //vertical lines
    for (int i = 0; i < 324; i = i + 54)
    {
    int xPosition = 25;
    CAShapeLayer *lineLayer = [CAShapeLayer layer];
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(xPosition + i, 100)];
    [path addLineToPoint:CGPointMake(xPosition + i, 400)];
    [path closePath];
    [lineLayer setPath:[path CGPath]];
    [lineLayer setLineWidth:5];
    [lineLayer setStrokeColor:[UIColor redColor].CGColor];
    [[[self view] layer] addSublayer:lineLayer];
    [lineLayer setName:@"LineLayer"];
    }
    
    //horizontal lines
    
    for (int i = 0; i < 360; i = i + 60)
    {
        int yPosition = 100;
        CAShapeLayer *lineLayer = [CAShapeLayer layer];
        UIBezierPath *path = [UIBezierPath bezierPath];
        [path moveToPoint:CGPointMake(25, yPosition + i)];
        [path addLineToPoint:CGPointMake((self.view.frame.size.width) - 25, yPosition + i)];
        [path closePath];
        [lineLayer setPath:[path CGPath]];
        [lineLayer setLineWidth:5];
        [lineLayer setStrokeColor:[UIColor redColor].CGColor];
        [[[self view] layer] addSublayer:lineLayer];
        [lineLayer setName:@"LineLayer"];
    }
    
    for (int i =1; i <6; i++)
    {
        
        
        for (int i =1; i < 6; i++)
        {
         CAShapeLayer *squareLayer=[CAShapeLayer layer];
        
        }
        
    }
    
    


}

//- (void) getScreenDimensions
//{
    //int width = self.view.frame.size.width;
    //int height = self.view.frame.size.height;
//}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
